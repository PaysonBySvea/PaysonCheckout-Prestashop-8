<?php

namespace Payson\Payments\Validation;

/**
 * Class ValidateAccountData
 * @package Payson\Payments\Validation
 */
class ValidateAccountData extends ValidationService
{
    /**
     * @param mixed $data
     */
    public function validate($data)
    {
        return true;
    }
}
